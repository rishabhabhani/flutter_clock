import 'package:flutter/material.dart';

class OrbitPainter extends CustomPainter {
  // values for math and specific sizes2
  double orbitRadius, planetRadius;

  // color values for design
  Color orbitColor, strokeColor;

  OrbitPainter({
    this.orbitRadius,
    this.orbitColor,
    this.planetRadius,
    this.strokeColor,
  }) : super();

  @override
  void paint(Canvas canvas, Size size) {
    // paint for the outer color of orbit
    Paint orbitPaint = Paint()
      ..color = orbitColor
      ..strokeWidth = 4.0
      ..strokeCap = StrokeCap.butt
      ..style = PaintingStyle.stroke;

    // paint for the planet object on orbit
    Paint planetPaint = Paint()
      ..color = orbitColor
      ..style = PaintingStyle.fill;

    // paint for giving the planet an invisibile stroke
    Paint planetStroke = Paint()
      ..color = strokeColor
      ..strokeWidth = 2.0
      ..style = PaintingStyle.stroke;

    canvas.drawCircle(
      size.center(Offset.zero),
      orbitRadius,
      orbitPaint,
    );

    canvas.drawCircle(
      Offset(orbitRadius, 0),
      planetRadius,
      planetPaint,
    );
    canvas.drawCircle(
      Offset(orbitRadius, 0),
      planetRadius,
      planetStroke,
    );
  }

  // repaints the canvas if any of the following valaues change
  @override
  bool shouldRepaint(OrbitPainter old) {
    return orbitColor != old.orbitColor ||
        strokeColor != old.strokeColor ||
        planetRadius != old.planetRadius ||
        orbitRadius != old.orbitRadius;
  }
}
