import 'package:flutter/services.dart';
import 'package:flutter_clock_helper/customizer.dart';
import 'package:flutter_clock_helper/model.dart';
import 'package:flutter/material.dart';

import 'galaxy_clock.dart';

void main() {
  // added in due to flutter error of binary messenger
  WidgetsFlutterBinding.ensureInitialized();

  // used for setting orientations and system ui visibilities.
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);
  SystemChrome.setEnabledSystemUIOverlays([]);

  // runs the galaxy clock app
  runApp(ClockCustomizer((ClockModel model) => GalaxyClock(model)));
}
