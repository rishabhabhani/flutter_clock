// Copyright 2019 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

import 'dart:async';

import 'package:flutter_clock_helper/model.dart';
import 'package:flutter/material.dart';
import 'package:flutter/semantics.dart';
import 'package:intl/intl.dart';
import 'package:vector_math/vector_math_64.dart' show radians;

import 'package:galaxy_clock/orbit_painter.dart';
import 'package:galaxy_clock/color_themes.dart';
import 'package:galaxy_clock/temp_painter.dart';
import 'package:galaxy_clock/constants.dart';

/// Total distance traveled by a second or a minute hand, each second or minute,
/// respectively.
final radiansPerTick = radians(360 / 60);

/// Total distance traveled by an hour hand, each hour, in radians.
final radiansPerHour = radians(360 / 12);

class GalaxyClock extends StatefulWidget {
  const GalaxyClock(this.model);

  final ClockModel model;

  @override
  _GalaxyClockState createState() => _GalaxyClockState();
}

class _GalaxyClockState extends State<GalaxyClock>
    with TickerProviderStateMixin {
  var _now = DateTime.now();
  var _temperature = '';
  var _temperatureRange = '';
  var _condition = '';
  var _location = '';
  Timer _timer;

  AnimationController _venusController;
  AnimationController _earthController;
  AnimationController _marsController;

  @override
  void initState() {
    super.initState();

    widget.model.addListener(_updateModel);

    // Controllers duration get set
    _marsController = AnimationController(
      vsync: this,
      duration: Duration(days: 1),
    );

    _venusController = AnimationController(
      vsync: this,
      duration: Duration(minutes: 1),
    );

    _earthController = AnimationController(
      vsync: this,
      duration: Duration(hours: 1),
    );

    // Controllers set to repeat so that whenever it finishes it can keep going
    _venusController.repeat();
    _earthController.repeat();
    _marsController.repeat();

    // Set the initial values.
    _updateTime();
    _updateModel();
  }

  // attaches and detaches listeners
  @override
  void didUpdateWidget(GalaxyClock oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.model != oldWidget.model) {
      oldWidget.model.removeListener(_updateModel);
      widget.model.addListener(_updateModel);
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    widget.model.removeListener(_updateModel);

    _venusController.dispose();
    _earthController.dispose();
    _marsController.dispose();

    super.dispose();
  }

  // handles updating of position and values for time handles and animation controllers
  void _updateHandels() {
    setState(() {
      // will run only we can retrieve current time model
      if (_now != null) {
        // times below are computed with respect to their lower times as decimals
        // to provide correct start point for animation controllers when updating.

        if (_venusController != null && _now.second != null) {
          _venusController.forward(
              from: (_now.second + _now.millisecond / 100) / 60);
          _venusController.repeat();
        }

        if (_earthController != null && _now.minute != null) {
          _earthController.forward(from: (_now.minute + _now.second / 60) / 60);
          _earthController.repeat();
        }

        // div helps in setting position of hour handle with respect to time format
        final div = widget.model.is24HourFormat ? 24 : 12;
        if (_marsController != null && _now.hour != null) {
          final hour = _now.hour + _now.minute / 60;
          final time = (_now.hour > 12 && div == 12) ? hour - 12 : hour;
          _marsController.forward(from: time / div);
          _marsController.repeat();
        }
      }
    });
  }

  // whenever any model value changes, the system gets updated along with handles.
  void _updateModel() {
    setState(() {
      _temperature = widget.model.temperatureString;
      _temperatureRange = '(${widget.model.low} - ${widget.model.highString})';
      _condition = widget.model.weatherString;
      _location = widget.model.location;

      _updateHandels();
    });
  }

  // gets called every second, it calls set state to update clock every second
  void _updateTime() {
    setState(() {
      _now = DateTime.now();
      // Update once per second. Make sure to do it at the beginning of each
      // new second, so that the clock is accurate.
      _timer = Timer(
        Duration(seconds: 1) - Duration(milliseconds: _now.millisecond),
        _updateTime,
      );
    });
  }

  // widget that sets up clock face
  Widget clockWidget(customTheme, weatherConditionFile) {
    return Stack(
      children: [
        Center(
          // this child contains images which depict current weather conditions accurately.
          child: Container(
            width: venusDistance - 10,
            height: venusDistance - 10,
            child: ClipOval(
              child: Align(
                heightFactor: 0.5,
                widthFactor: 0.5,
                child: Image.asset('assets/images/' + weatherConditionFile),
              ),
            ),
          ),
        ),

        //RotationTransitions are used instead of animations for custom painters as it provides
        //flexibility and ease of animating the clock handles

        Center(
          child: RotationTransition(
            turns: _marsController,
            child: new Container(
              constraints: BoxConstraints.tight(Size.square(marsDistance)),
              child: CustomPaint(
                painter: OrbitPainter(
                  orbitColor: customTheme[ColorPallete.marsColor],
                  orbitRadius: marsDistance / 2,
                  planetRadius: marsSize / 2,
                  strokeColor: customTheme[ColorPallete.backgroundColor],
                ),
              ),
            ),
          ),
        ),
        Center(
          child: RotationTransition(
            turns: _earthController,
            child: new Container(
              constraints: BoxConstraints.tight(Size.square(earthDistance)),
              child: CustomPaint(
                painter: OrbitPainter(
                  orbitColor: customTheme[ColorPallete.earthColor],
                  orbitRadius: earthDistance / 2,
                  planetRadius: eveSize / 2,
                  strokeColor: customTheme[ColorPallete.backgroundColor],
                ),
              ),
            ),
          ),
        ),
        Center(
          child: RotationTransition(
            turns: _venusController,
            child: new Container(
              constraints: BoxConstraints.tight(Size.square(venusDistance)),
              child: CustomPaint(
                painter: OrbitPainter(
                  orbitColor: customTheme[ColorPallete.venusColor],
                  orbitRadius: venusDistance / 2,
                  planetRadius: eveSize / 2,
                  strokeColor: customTheme[ColorPallete.backgroundColor],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // function extracts low and high values of temperature range along with their units
  extractRange(String range) {
    String low = "";
    String high = "";
    String sign = "";

    // simple string manipulations used to remove and extract values.
    range = range.substring(1, range.length - 1);
    sign = range.substring(range.length - 2, range.length);
    range = range.substring(0, range.length - 2);
    var ranges = range.split(" - ");

    low = ranges[0] + sign;
    high = ranges[1] + sign;

    return [low, high];
  }

  @override
  Widget build(BuildContext context) {
    // custom theme is the holder for light and dark theme color values
    final customTheme = Theme.of(context).brightness == Brightness.light
        ? lightTheme
        : darkTheme;

    // time is string representative for time wrt time format chosen
    var time;
    if (!widget.model.is24HourFormat)
      time = DateFormat.jm().format(DateTime.now());
    else
      time = DateFormat.Hm().format(DateTime.now());

    var range = extractRange(_temperatureRange);

    // used to select the correct image for current weather representation
    final weatherConditionFile = 'weather_' + _condition.toString() + '.png';

    return Semantics.fromProperties(
      properties: SemanticsProperties(
        label: 'Analog clock with time $time',
        value: time,
      ),
      child: Container(
        color: customTheme[ColorPallete.backgroundColor],
        child: Padding(
          padding: EdgeInsets.fromLTRB(marginLengths, 0, 0, 0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              // clock widget container
              Container(
                height: marsDistance,
                width: marsDistance,
                child: clockWidget(customTheme, weatherConditionFile),
              ),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    // sat container
                    Container(
                      width: marsDistance,
                      height: marsDistance,
                      child: CustomPaint(
                        painter: TempPainter(
                          startTemp: range[0],
                          currentTemp: _temperature,
                          endTemp: range[1],
                          baseColor: customTheme[ColorPallete.temperatureColor],
                          spaceColor: customTheme[ColorPallete.metalColor],
                          backgroundColor:
                              customTheme[ColorPallete.backgroundColor],
                          textColor: customTheme[ColorPallete.textColor],
                        ),
                      ),
                    ),
                    // location container
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Icon(
                          Icons.room,
                          color: customTheme[ColorPallete.locationColor],
                          size: locationIconSize,
                        ),
                        Flexible(
                          child: Container(
                            margin:
                                EdgeInsets.fromLTRB(0, 0, smallGapLengths, 0),
                            child: Text(
                              _location.toUpperCase(),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: customTheme[ColorPallete.locationColor],
                                fontSize: locationTextSize,
                                fontStyle: FontStyle.normal,
                                letterSpacing: 2,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    // text container
                    Container(
                      width: double.infinity,
                      margin: EdgeInsets.fromLTRB(
                          marginLengths, 0, marginLengths, marginLengths),
                      padding: EdgeInsets.all(smallGapLengths),
                      decoration: BoxDecoration(
                        color: customTheme[ColorPallete.backgroundColor],
                        border: Border.all(
                          color: customTheme[ColorPallete.metalColor],
                          width: 2,
                        ),
                      ),
                      child: Center(
                        child: Text(
                          time,
                          style: TextStyle(
                            color: customTheme[ColorPallete.textColor],
                            fontSize: timeTextSize,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 8.0,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
