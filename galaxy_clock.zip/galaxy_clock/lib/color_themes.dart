import 'package:flutter/material.dart';

enum ColorPallete {
  // Planetary Colors
  venusColor,
  earthColor,
  marsColor,

  // Accent Colors
  backgroundColor,
  textColor,

  // Other Colors
  locationColor,
  temperatureColor,
  metalColor,
}

final lightTheme = {
  ColorPallete.venusColor: Colors.amber,
  ColorPallete.earthColor: Colors.blue,
  ColorPallete.marsColor: Colors.red,
  ColorPallete.backgroundColor: Colors.grey[50],
  ColorPallete.textColor: Colors.grey[900],
  ColorPallete.locationColor: Colors.lightGreen[700],
  ColorPallete.temperatureColor: Colors.lightBlue[700],
  ColorPallete.metalColor: Colors.blueGrey[800],
};

final darkTheme = {
  ColorPallete.venusColor: Colors.amberAccent,
  ColorPallete.earthColor: Colors.blueAccent,
  ColorPallete.marsColor: Colors.redAccent,
  ColorPallete.backgroundColor: Colors.grey[900],
  ColorPallete.textColor: Colors.grey[50],
  ColorPallete.locationColor: Colors.lightGreen[300],
  ColorPallete.temperatureColor: Colors.lightBlue[300],
  ColorPallete.metalColor: Colors.blueGrey[200],
};
