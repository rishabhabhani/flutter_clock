import 'package:flutter/material.dart';
import 'package:galaxy_clock/constants.dart';

class TempPainter extends CustomPainter {
  // Temperature values
  String startTemp, endTemp;
  String currentTemp;

  // Color values for designing
  Color baseColor, spaceColor, backgroundColor, textColor;

  TempPainter({
    this.startTemp,
    this.endTemp,
    this.currentTemp,
    this.baseColor,
    this.spaceColor,
    this.backgroundColor,
    this.textColor,
  }) : super();

  @override
  void paint(Canvas canvas, Size size) {
    // Paint for filling shapes with opaque yet "transparent" Color
    Paint paint = Paint()
      ..color = textColor
      ..style = PaintingStyle.fill;

    // Paint for coloring the border of shapes
    Paint strokePaint = Paint()
      ..color = spaceColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;

    // Positioning canvas for easy painting
    canvas.translate(size.height / 2, size.height / 2);

    var path = Path();

    // Rects for creating joints of satellite
    path.addRect(
      Rect.fromLTWH(
        -baseSize / 2 - spacing - panelSize / 2,
        -spacing / 2,
        baseSize + 2 * spacing + panelSize,
        spacing,
      ),
    );

    path.addRect(
      new Rect.fromCenter(
        center: Offset(0, baseSize / 4 + spacing),
        height: baseSize / 2 + spacing,
        width: spacing,
      ),
    );

    canvas.drawPath(path, paint);
    canvas.drawPath(path, strokePaint);

    // Starting new path for rest of sat
    path = Path();

    // Rect for panels of sat
    for (int i = 0, m = 1; i < 2; i++, m *= -1) {
      path.addRect(
        new Rect.fromCenter(
          center: Offset(m * (baseSize / 2 + spacing + panelSize / 2), 0),
          width: panelSize,
          height: panelSize / 2,
        ),
      );
    }

    // shape for base of sat
    path.addOval(
      new Rect.fromCircle(
        center: Offset.zero,
        radius: baseSize / 2,
      ),
    );

    // shape for antenna of sat
    path.addOval(
      new Rect.fromCircle(
        center: Offset(0, baseSize / 2 + spacing * 3 / 2),
        radius: spacing,
      ),
    );

    paint.color = backgroundColor;

    canvas.drawPath(path, paint);
    canvas.drawPath(path, strokePaint);

    // new path for arcs of sat
    path = new Path();

    strokePaint.strokeWidth = strokeSize;

    for (int i = 2; i < 5; i++) {
      path.addArc(
        Rect.fromCircle(
          center: Offset(
            0,
            baseSize / 2 + spacing * 3 / 2,
          ),
          radius: spacing * i,
        ),
        0.5, // startAngle
        2, // sweep angle
      );
    }

    strokePaint.color = baseColor;

    canvas.drawPath(path, strokePaint);

    paintText(canvas);
  }

  // Used for painting the various text at particular places
  void paintText(canvas) {
    var textPainter = TextPainter()
      ..textAlign = TextAlign.center
      ..textDirection = TextDirection.ltr;

    var textStyle = TextStyle(
      color: baseColor,
      fontWeight: FontWeight.w900,
      fontStyle: FontStyle.normal,
      letterSpacing: 10,
      fontSize: temperatureTextSize,
    );

    // TEMPERATURE TEXT
    textPainter.text = new TextSpan(
      text: "TEMPERATURE",
      style: textStyle,
    );

    textPainter.layout();
    textPainter.paint(
      canvas,
      Offset(
          -textPainter.width / 2, -baseSize / 2 - spacing - textPainter.height),
    );
    // ===================================

    // MIN MAX TEXT
    textStyle = TextStyle(
      color: baseColor,
      fontWeight: FontWeight.w900,
      fontStyle: FontStyle.normal,
      letterSpacing: 5,
      fontSize: temperatureRangeTextSize,
    );

    textPainter.text = new TextSpan(
      text: "MIN",
      style: textStyle,
    );

    textPainter.layout();
    textPainter.paint(
      canvas,
      Offset(-baseSize / 2 - spacing - panelSize / 2 - textPainter.width / 2,
          panelSize / 4 + spacing - textPainter.height / 2),
    );

    textPainter.text = new TextSpan(
      text: "MAX",
      style: textStyle,
    );

    textPainter.layout();
    textPainter.paint(
      canvas,
      Offset(baseSize / 2 + spacing + panelSize / 2 - textPainter.width / 2,
          panelSize / 4 + spacing - textPainter.height / 2),
    );
    //==================================

    // Temperature range printers, will only work if they are not null
    if (currentTemp != null && startTemp != null && endTemp != null) {
      textStyle = TextStyle(
        fontSize: temperatureCurrentTextSize,
        color: baseColor,
        fontWeight: FontWeight.bold,
      );

      textPainter.text = new TextSpan(
        text: currentTemp,
        style: textStyle,
      );

      textPainter.layout();
      textPainter.paint(
        canvas,
        Offset(
          -textPainter.width / 2,
          -textPainter.height / 2,
        ),
      );

      textStyle = TextStyle(
        fontSize: temperatureCurrentRangeTextSize,
        color: textColor,
        fontWeight: FontWeight.w600,
      );

      textPainter.text = new TextSpan(
        text: startTemp,
        style: textStyle,
      );

      textPainter.layout();
      textPainter.paint(
        canvas,
        Offset(
          -baseSize / 2 - spacing - panelSize / 2 - textPainter.width / 2,
          -textPainter.height / 2,
        ),
      );

      textPainter.text = new TextSpan(
        text: endTemp,
        style: textStyle,
      );

      textPainter.layout();
      textPainter.paint(
        canvas,
        Offset(
          baseSize / 2 + spacing + panelSize / 2 - textPainter.width / 2,
          -textPainter.height / 2,
        ),
      );
    }
  }

  // will repaint the custom obj if any of the following values change.
  @override
  bool shouldRepaint(TempPainter old) {
    return startTemp != old.startTemp ||
        currentTemp != old.currentTemp ||
        endTemp != old.endTemp ||
        backgroundColor != old.backgroundColor ||
        spaceColor != old.spaceColor;
  }
}
