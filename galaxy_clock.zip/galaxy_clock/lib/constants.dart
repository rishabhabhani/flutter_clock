// Value Constants for math and specific sizing

// Planet sizes, orbiting in clock handles
final eveSize = 15.00; // second and minute planet size
final marsSize = 10.00; // hour planet size

// Planet Orbit Sizes, size of clock handles
final venusDistance = 100.00; // second orbit size
final earthDistance = 140.00; // minute orbit size
final marsDistance = 180.00; // hour orbit size

// Note,
// delta between clock handle size should be same
// and twice the eveSize should be less than the delta between clock handle.

// galaxy_clock margin and padding lengthss
final marginLengths =
    20.00; // used for margins of clock face and time container
final smallGapLengths =
    4.00; // used for padding time inside container & seperation b/w loc and time

// Used for satellite sizes
final baseSize = 60.00; // center piece of sat, shows current temp
final panelSize = 60.00; // ends of sat, shows low-high temp
const spacing = 10.00; // used for creating joints of sat
// DO NOT CHANGE SPACING VALUE

// Note,
// Not necessary to keep base and panel size same.

final strokeSize = 2.00; // used for creating the comms arc of sat

// Text font sizes used in galaxy_clock
final timeTextSize = 24.00; // used for main time text size
final locationTextSize = 12.00; // following used for location size
final locationIconSize = 14.00;

// fonts used in temp_painter
final temperatureTextSize = 12.00; // used for temp text above sat
final temperatureRangeTextSize = 10.00; // used for min max text below panel
final temperatureCurrentTextSize = 14.00; // used for current temp text on base
final temperatureCurrentRangeTextSize =
    12.00; // used for low-high temp text on panels
